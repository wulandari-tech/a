const requimeBoostService = require('../services/requimeBoostService');
const Order = require('../models/order');
const User = require('../models/user');
const { v4: uuidv4 } = require('uuid');
const { createDynamicOrkutQris } = require('../services/orkutQrisService');

exports.getLayananIndexPage = async (req, res) => {
    try {
        res.render('layanan/index_new', {
            pageTitle: "Pilih Layanan Digital",
            activePage: 'layanan'
        });
    } catch (error) {
        console.error(error);
        req.flash('error_messages', 'Gagal memuat halaman layanan.');
        res.redirect('/');
    }
};

exports.getPrabayarPage = async (req, res) => {
    try {
        const serviceData = await requimeBoostService.getPrabayarServices();
        let categories = {};
        let operators = new Set();

        if (serviceData.status && serviceData.data) {
            serviceData.data.forEach(service => {
                const tipe = service.tipe || 'Lainnya';
                if (!categories[tipe]) {
                    categories[tipe] = [];
                }
                categories[tipe].push(service);
                if (service.operator) {
                    operators.add(service.operator);
                }
            });
        } else {
            req.flash('error_messages', serviceData.data.pesan || 'Gagal mengambil daftar layanan prabayar.');
        }
        
        res.render('layanan/prabayar_page', {
            pageTitle: "Layanan Prabayar",
            categories: categories,
            operators: Array.from(operators).sort(),
            rawServiceData: serviceData.status ? serviceData.data : [],
            activePage: 'layanan'
        });
    } catch (error) {
        console.error(error);
        req.flash('error_messages', 'Terjadi kesalahan saat memuat layanan prabayar.');
        res.redirect('/layanan');
    }
};

exports.getPascabayarPage = async (req, res) => {
    try {
        const serviceData = await requimeBoostService.getPascabayarServices();
        let categorizedServices = [];

        if (serviceData.status && serviceData.data) {
            categorizedServices = serviceData.data.filter(s => s.status && s.status.toLowerCase() === 'normal');
        } else {
            req.flash('error_messages', serviceData.data.pesan || 'Gagal mengambil daftar layanan pascabayar.');
        }
        
        res.render('layanan/pascabayar_page', {
            pageTitle: "Layanan Pascabayar",
            services: categorizedServices,
            activePage: 'layanan'
        });
    } catch (error) {
        console.error(error);
        req.flash('error_messages', 'Terjadi kesalahan saat memuat layanan pascabayar.');
        res.redirect('/layanan');
    }
};

exports.getSosmedPage = async (req, res) => {
    const server = req.query.server || 'sosmed';
    try {
        const serviceData = await requimeBoostService.getSosmedServices(server);
        let categories = {};

        if (serviceData.status && serviceData.data) {
            serviceData.data.forEach(service => {
                const kategori = service.kategori || 'Lainnya';
                if (!categories[kategori]) {
                    categories[kategori] = [];
                }
                categories[kategori].push(service);
            });
        } else {
            req.flash('error_messages', serviceData.data.pesan || `Gagal mengambil daftar layanan SMM (${server}).`);
        }
        
        res.render('layanan/sosmed_page', {
            pageTitle: `Layanan Sosial Media (${server.replace('sosmed', 'Server ' + (server.slice(-1) || '1'))})`,
            categories: categories,
            currentServer: server,
            rawServiceData: serviceData.status ? serviceData.data : [],
            activePage: 'layanan'
        });
    } catch (error) {
        console.error(error);
        req.flash('error_messages', `Terjadi kesalahan saat memuat layanan SMM (${server}).`);
        res.redirect('/layanan');
    }
};


exports.getLayananCheckoutPage = async (req, res) => {
    const { product_code, product_name, product_price, target_id, zone_id, service_type, server_smm } = req.query;

    if (!product_code || !product_name || !product_price || !target_id || !service_type) {
        req.flash('error_messages', 'Data layanan tidak lengkap untuk checkout.');
        return res.redirect('/layanan');
    }

    const product = {
        code: product_code,
        name: product_name,
        price: parseInt(product_price),
        targetId: target_id,
        zoneId: zone_id || '',
        serviceType: service_type, 
        serverSMM: server_smm || ''
    };

    res.render('layanan/checkout_new', {
        pageTitle: `Checkout: ${product.name}`,
        product,
        user: req.session.user,
        activePage: 'layanan'
    });
};

exports.processLayananOrder = async (req, res) => {
    const { product_code, product_name, product_price, target_id, zone_id, payment_method, service_type, server_smm, quantity_smm } = req.body;
    const userId = req.session.user._id;
    const telegramBot = req.app.get('telegramBot');
    const ownerChatId = process.env.TELEGRAM_OWNER_ID;

    try {
        const user = await User.findById(userId);
        if (!user) {
            req.flash('error_messages', 'User tidak ditemukan.');
            return res.redirect('/logout');
        }

        const price = parseInt(product_price);
        let totalPrice = price;
        let orderQuantity = 1;

        if (service_type === 'sosmed' && quantity_smm) {
            const qty = parseInt(quantity_smm);
            if (isNaN(qty) || qty <= 0) {
                req.flash('error_messages', 'Jumlah untuk layanan SMM tidak valid.');
                return res.redirect('back');
            }
            orderQuantity = qty;
            totalPrice = Math.round((price / 1000) * qty);
        }


        const orderData = {
            user: userId,
            productNameSnapshot: product_name,
            productCodeSnapshot: product_code,
            productType: service_type,
            quantity: orderQuantity,
            pricePerItem: service_type === 'sosmed' ? (price / 1000) : price,
            totalPrice: totalPrice,
            paymentMethodType: payment_method,
            status: 'pending_payment',
            reffId: `PPOB-${uuidv4().split('-')[0].toUpperCase()}`,
            requimeboostOrderDetails: {
                target: target_id,
                zoneId: zone_id || null,
                serverSMM: server_smm || null,
            }
        };

        if (payment_method === 'balance') {
            if (user.balance < totalPrice) {
                req.flash('error_messages', 'Saldo Anda tidak mencukupi.');
                return res.redirect('back');
            }
            user.balance -= totalPrice;
            orderData.status = 'processing_provider'; 
            orderData.paidAt = new Date();
        } else if (payment_method === 'orkut_qris') {
            const orkutAmount = totalPrice;
            const orkutFeePercent = parseFloat(process.env.ORKUT_QRIS_FEE_PERCENTAGE || 0.7);
            const orkutFee = Math.round(orkutAmount * (orkutFeePercent / 100));
            const amountToPayOrkut = orkutAmount + orkutFee;

            const qrisData = await createDynamicOrkutQris(amountToPayOrkut, `Order ${orderData.reffId} - ${product_name}`);
            if (qrisData.success) {
                orderData.paymentGatewayDetails = {
                    gateway: 'ORKUT_QRIS',
                    orkutReffId: qrisData.orkutReffId,
                    qrImageUrl: qrisData.qrImageUrl,
                    amountToPay: amountToPayOrkut,
                    fee: orkutFee,
                    expiredAt: qrisData.expiredAt
                };
            } else {
                req.flash('error_messages', `Gagal membuat QRIS: ${qrisData.message}`);
                return res.redirect('back');
            }
        } else {
            req.flash('error_messages', 'Metode pembayaran tidak valid.');
            return res.redirect('back');
        }
        
        const newOrder = new Order(orderData);
        await newOrder.save();
        await user.save();
        
        if (req.session.user) req.session.user.balance = user.balance;
        req.session.save();

        if (telegramBot && ownerChatId) {
            const notifMessage = `📲 *ORDER PPOB BARU* 📲\n\nID: \`${newOrder.reffId}\`\nLayanan: *${product_name}*\nUser: *${user.username}*\nTarget: \`${target_id}${zone_id ? `(${zone_id})` : ''}\`\nTotal: Rp ${totalPrice.toLocaleString('id-ID')}\nMetode: ${payment_method}\nStatus: *${newOrder.status.replace(/_/g, ' ')}*`;
            try {
                await telegramBot.sendMessage(ownerChatId, notifMessage, { parse_mode: 'Markdown' });
            } catch (tgError) {}
        }

        if (newOrder.status === 'pending_payment') {
            res.redirect(`/layanan/order/${newOrder._id}/payment`);
        } else if (newOrder.status === 'processing_provider') {
            res.redirect(`/layanan/order/${newOrder._id}/status?auto_process=true`);
        } else {
            res.redirect(`/layanan/order/${newOrder._id}/status`);
        }

    } catch (error) {
        console.error(error);
        req.flash('error_messages', 'Terjadi kesalahan saat memproses pesanan layanan.');
        res.redirect('back');
    }
};


exports.getLayananOrderPaymentPage = async (req, res) => {
    try {
        const order = await Order.findById(req.params.orderId);
        if (!order || order.user.toString() !== req.session.user._id.toString()) {
            req.flash('error_messages', 'Order tidak ditemukan.');
            return res.redirect('/user/profile');
        }
        if (order.status !== 'pending_payment') {
            return res.redirect(`/layanan/order/${order._id}/status`);
        }
        if (!order.paymentGatewayDetails || !order.paymentGatewayDetails.qrImageUrl) {
            req.flash('error_messages', 'Detail pembayaran QRIS tidak tersedia.');
            return res.redirect(`/layanan/order/${order._id}/status`);
        }
         if (new Date() > new Date(order.paymentGatewayDetails.expiredAt)) {
            order.status = 'payment_failed';
            order.paymentGatewayDetails.statusMessage = 'Waktu pembayaran QRIS telah habis.';
            await order.save();
            req.flash('error_messages', 'Waktu pembayaran QRIS untuk order ini telah habis.');
            return res.redirect(`/layanan/order/${order._id}/status`);
        }

        res.render('layanan/order_payment_new', {
            pageTitle: `Pembayaran Order PPOB #${order.reffId}`,
            order,
            service: { 
                title: order.productNameSnapshot, 
                categorySlug: order.productType, 
                slug: order.productCodeSnapshot 
            }
        });
    } catch (error) {
        console.error(error);
        req.flash('error_messages', 'Gagal memuat halaman pembayaran.');
        res.redirect('/user/profile');
    }
};

exports.checkLayananPaymentAndProcessOrder = async (req, res) => {
    const { orderId } = req.params;
    try {
        const order = await Order.findById(orderId).populate('user', 'username');
        if (!order || order.user._id.toString() !== req.session.user._id.toString()) {
            return res.status(404).json({ success: false, message: "Order tidak ditemukan." });
        }

        if (order.status !== 'pending_payment') {
            return res.json({ success: true, status: order.status, message: `Status sudah ${order.status}.`});
        }
        if (new Date() > new Date(order.paymentGatewayDetails.expiredAt)) {
            order.status = 'payment_failed';
            await order.save();
            return res.json({ success: true, status: 'payment_failed', message: 'Waktu pembayaran habis.' });
        }

        let paymentConfirmed = false;
        if (order.paymentMethodType === 'orkut_qris' && order.paymentGatewayDetails.orkutReffId) {
            const paymentStatus = await checkOrkutQrisPaymentStatus(order.paymentGatewayDetails.orkutReffId, order.paymentGatewayDetails.amountToPay, order.lastCheckedPaymentAt);
            order.lastCheckedPaymentAt = new Date();
            if (paymentStatus.success && paymentStatus.isPaid) {
                paymentConfirmed = true;
                order.paymentGatewayDetails.statusMessage = "Pembayaran QRIS terkonfirmasi.";
                order.providerTransactionDetails = paymentStatus.transaction;
                order.paidAt = new Date();
            }
        }

        if (paymentConfirmed) {
            order.status = 'processing_provider';
            await order.save();
            
            const autoProcess = req.query.auto_process === 'true' || (req.body && req.body.auto_process === true);
            if(autoProcess){
                 await processOrderWithProvider(order, req.app.get('telegramBot'));
            }
            return res.json({ success: true, status: order.status, message: 'Pembayaran berhasil, pesanan akan diproses.', auto_process_triggered: autoProcess });
        } else {
            await order.save();
            return res.json({ success: false, status: 'pending_payment', message: 'Pembayaran masih pending.' });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Kesalahan server saat cek pembayaran.' });
    }
};

async function processOrderWithProvider(order, telegramBot) {
    if (order.status !== 'processing_provider') return;

    let providerResponse;
    let success = false;
    let providerMessage = 'Gagal memproses dengan provider.';
    let providerTrxId = null;

    try {
        if (order.productType === 'prabayar' || ['pulsa', 'data', 'game', 'pln_prabayar', 'voucher'].includes(order.productType.toLowerCase())) {
            providerResponse = await requimeBoostService.placePrabayarOrder(order.productCodeSnapshot, order.requimeboostOrderDetails.target, order.reffId);
        } else if (order.productType === 'pascabayar' || ['pln', 'bpjs', 'pdam'].includes(order.productType.toLowerCase())) {
             providerResponse = await requimeBoostService.placePascabayarOrder(order.productCodeSnapshot, order.requimeboostOrderDetails.target, order.reffId);
        } else if (order.productType === 'sosmed') {
            providerResponse = await requimeBoostService.placeSosmedOrder(order.productCodeSnapshot, order.requimeboostOrderDetails.target, order.quantity, order.requimeboostOrderDetails.serverSMM, order.reffId);
        } else {
            order.status = 'failed';
            order.providerResponse = { pesan: 'Tipe produk tidak didukung untuk pemrosesan otomatis.' };
            await order.save();
            return;
        }

        if (providerResponse && providerResponse.status === true && providerResponse.data && providerResponse.data.id_pemesanan) {
            order.status = 'completed';
            providerMessage = providerResponse.data.pesan || 'Pesanan berhasil diproses oleh provider.';
            providerTrxId = providerResponse.data.id_pemesanan;
            success = true;
        } else if (providerResponse && providerResponse.data && providerResponse.data.pesan) {
            order.status = 'failed';
            providerMessage = providerResponse.data.pesan;
        } else {
            order.status = 'failed';
        }
        order.requimeboostOrderDetails.providerOrderId = providerTrxId;
        order.providerResponse = providerResponse;
        await order.save();
        
        const ownerChatId = process.env.TELEGRAM_OWNER_ID;
        if (telegramBot && ownerChatId) {
            const user = await User.findById(order.user).select('username').lean();
            const statusEmoji = success ? "✅" : "❌";
            const notifMessage = `${statusEmoji} *UPDATE ORDER PPOB* ${statusEmoji}\n\nID Internal: \`${order.reffId}\`\nID Provider: \`${providerTrxId || 'N/A'}\`\nLayanan: *${order.productNameSnapshot}*\nUser: *${user ? user.username : 'N/A'}*\nTarget: \`${order.requimeboostOrderDetails.target}\`\nStatus: *${order.status.toUpperCase()}*\nPesan Provider: ${providerMessage}`;
            try {
                await telegramBot.sendMessage(ownerChatId, notifMessage, { parse_mode: 'Markdown' });
            } catch (tgError) {}
        }


    } catch (error) {
        console.error(`Error processing order ${order._id} with provider:`, error);
        order.status = 'failed';
        order.providerResponse = { pesan: 'Kesalahan internal saat menghubungi provider.' };
        await order.save();
    }
}


exports.getLayananOrderStatusPage = async (req, res) => {
    try {
        const order = await Order.findById(req.params.orderId).populate('user', 'username');
        if (!order || order.user._id.toString() !== req.session.user._id.toString()) {
            req.flash('error_messages', 'Order tidak ditemukan.');
            return res.redirect('/user/profile');
        }
        
        if (order.status === 'processing_provider' && req.query.auto_process === 'true') {
            await processOrderWithProvider(order, req.app.get('telegramBot'));
            const updatedOrder = await Order.findById(req.params.orderId);
             res.render('layanan/order_status_new', {
                pageTitle: `Status Order PPOB #${updatedOrder.reffId}`,
                order: updatedOrder,
                service: { 
                    title: updatedOrder.productNameSnapshot, 
                    categorySlugForUrl: updatedOrder.productType, 
                    slugForUrl: updatedOrder.productCodeSnapshot 
                }
            });
            return;
        }


        res.render('layanan/order_status_new', {
            pageTitle: `Status Order PPOB #${order.reffId}`,
            order,
            service: { 
                title: order.productNameSnapshot, 
                categorySlugForUrl: order.productType, 
                slugForUrl: order.productCodeSnapshot
            }
        });
    } catch (error) {
        console.error(error);
        req.flash('error_messages', 'Gagal memuat status order.');
        res.redirect('/user/profile');
    }
};


exports.checkPascabayarBillApi = async (req, res) => {
    const { service_id, target_no } = req.body;
    if (!service_id || !target_no) {
        return res.status(400).json({ success: false, message: 'Parameter tidak lengkap.' });
    }
    try {
        const billData = await requimeBoostService.checkPascabayarBill(service_id, target_no);
        if (billData.status && billData.data) {
            res.json({ success: true, data: billData.data });
        } else {
            res.json({ success: false, message: billData.data.pesan || 'Gagal cek tagihan.' });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Kesalahan server saat cek tagihan.' });
    }
};