const axios = require('axios');

const API_KEY = process.env.REQUIMEBOOST_API_KEY;
const PIN = process.env.REQUIMEBOOST_PIN;
const API_URL = process.env.REQUIMEBOOST_API_URL;

async function makeApiRequest(endpoint, additionalParams = {}) {
    if (!API_KEY || !PIN) {
        console.error('RequimeBoost API Key atau PIN tidak diset.');
        return { status: false, data: { pesan: 'Konfigurasi API Provider tidak lengkap.' } };
    }
    try {
        const params = new URLSearchParams();
        params.append('api_key', API_KEY);
        params.append('pin', PIN);
        for (const key in additionalParams) {
            params.append(key, additionalParams[key]);
        }

        const response = await axios.post(`${API_URL}/${endpoint}`, params);
        return response.data;
    } catch (error) {
        console.error(`Error calling RequimeBoost API ${endpoint}:`, error.response ? error.response.data : error.message);
        return { status: false, data: { pesan: error.message || 'Gagal menghubungi provider.' } };
    }
}

exports.getPrabayarServices = async () => {
    return makeApiRequest('prabayar', { action: 'layanan' });
};

exports.getPascabayarServices = async () => {
    return makeApiRequest('pascabayar', { action: 'layanan' });
};

exports.getSosmedServices = async (serverType = 'sosmed') => {
    let endpoint = 'sosmed';
    if (serverType === 'sosmed2') endpoint = 'sosmed2';
    if (serverType === 'sosmed3') endpoint = 'sosmed3';
    return makeApiRequest(endpoint, { action: 'layanan' });
};

exports.placePrabayarOrder = async (serviceId, target, reffId = null) => {
    const params = {
        action: 'pemesanan',
        layanan: serviceId,
        target: target,
    };
    if (reffId) params.id_reff = reffId;
    return makeApiRequest('prabayar', params);
};

exports.placePascabayarOrder = async (serviceId, target, reffId = null) => {
     const params = {
        action: 'pemesanan',
        layanan: serviceId,
        target: target,
    };
    if (reffId) params.id_reff = reffId;
    return makeApiRequest('pascabayar', params);
};


exports.placeSosmedOrder = async (serviceId, target, quantity, serverType = 'sosmed', reffId = null) => {
    let endpoint = 'sosmed';
    if (serverType === 'sosmed2') endpoint = 'sosmed2';
    if (serverType === 'sosmed3') endpoint = 'sosmed3';
    
    const params = {
        action: 'pemesanan',
        layanan: serviceId,
        target: target,
        jumlah: quantity
    };
    if (reffId) params.id_reff = reffId;
    return makeApiRequest(endpoint, params);
};


exports.checkPrabayarOrderStatus = async (orderId) => {
    return makeApiRequest('prabayar', { action: 'status', id_pemesanan: orderId });
};

exports.checkPascabayarOrderStatus = async (orderId) => {
    return makeApiRequest('pascabayar', { action: 'status', id_pemesanan: orderId });
};

exports.checkSosmedOrderStatus = async (orderId, serverType = 'sosmed') => {
    let endpoint = 'sosmed';
    if (serverType === 'sosmed2') endpoint = 'sosmed2';
    if (serverType === 'sosmed3') endpoint = 'sosmed3';
    return makeApiRequest(endpoint, { action: 'status', id_pemesanan: orderId });
};

exports.checkPascabayarBill = async (serviceId, target) => {
    return makeApiRequest('pascabayar', { action: 'cek-tagihan', layanan: serviceId, target: target });
};