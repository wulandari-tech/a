const express = require('express');
const router = express.Router();
const ppobController = require('../controllers/ppobController');
const { isAuthenticated } = require('../middleware/authMiddleware');
const { check } = require('express-validator');


router.get('/layanan', ppobController.getLayananIndexPage);

router.get('/layanan/prabayar', isAuthenticated, ppobController.getPrabayarPage);
router.get('/layanan/pascabayar', isAuthenticated, ppobController.getPascabayarPage);
router.get('/layanan/sosmed', isAuthenticated, ppobController.getSosmedPage);


router.get('/layanan/checkout', isAuthenticated, [
    check('product_code', 'Kode produk tidak valid').notEmpty().escape(),
    check('product_name', 'Nama produk tidak valid').notEmpty().escape(),
    check('product_price', 'Harga produk tidak valid').isInt({ gt: 0 }),
    check('target_id', 'Target ID tidak boleh kosong').notEmpty().escape(),
    check('service_type', 'Tipe layanan tidak valid').notEmpty().escape(),
    check('quantity_smm', 'Jumlah SMM tidak valid').optional().isInt({ gt: 0 })
], ppobController.getLayananCheckoutPage);


router.post('/layanan/order/process', isAuthenticated, [
    check('product_code', 'Kode produk diperlukan').notEmpty().escape(),
    check('product_name', 'Nama produk diperlukan').notEmpty().escape(),
    check('product_price', 'Harga produk diperlukan').isInt({ gt: 0 }),
    check('target_id', 'Target ID diperlukan').notEmpty().escape(),
    check('service_type', 'Tipe layanan diperlukan').notEmpty().escape(),
    check('payment_method', 'Metode pembayaran diperlukan').notEmpty().isIn(['balance', 'orkut_qris', 'midtrans_gateway']),
    check('quantity_smm', 'Jumlah SMM harus angka positif').optional().isInt({min: 1})
], ppobController.processLayananOrder);


router.get('/layanan/order/:orderId/payment', isAuthenticated, ppobController.getLayananOrderPaymentPage);
router.get('/layanan/order/:orderId/status', isAuthenticated, ppobController.getLayananOrderStatusPage);
router.get('/layanan/order/:orderId/check-payment-and-process', isAuthenticated, ppobController.checkLayananPaymentAndProcessOrder);


router.post('/api/layanan/pascabayar/cek-tagihan', isAuthenticated, [
    check('service_id', 'ID Layanan diperlukan').notEmpty().escape(),
    check('target_no', 'Nomor Target diperlukan').notEmpty().escape()
], ppobController.checkPascabayarBillApi);

module.exports = router;